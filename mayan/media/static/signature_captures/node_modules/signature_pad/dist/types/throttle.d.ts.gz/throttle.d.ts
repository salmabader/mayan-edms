export declare function throttle(fn: (...args: any[]) => any, wait?: number): (this: any, ...args: any[]) => any;
